# Panda gripper contact benchmark

This is a native MuJoCo contact task for the transfer instrument's sample-X
micrometer. A Franka Panda parallel gripper closes, turns the knob by approximately
−15°, releases it, then retracts. The intended stage displacement is −20.833 µm.
The wrist has four force-limited Cartesian degrees of freedom; it is a test
fixture, not an articulated robot arm. The instrument has no active bench drives
in the composed scene: only gripper/knob contacts transfer the robot's motion.

## Run

Python 3.10 or newer is recommended. From this directory:

```sh
python -m venv .venv
. .venv/bin/activate
python -m pip install -r requirements.txt
python robotics/validate_gripper.py --out validation/robotics
```

The runner executes seeds 0, 11 and 37 with the same policy in four conditions:
normal contact, disabled robot contacts, missed grasp, and no rotation. The contact
condition must reach the target, release, settle and retract without unintended
contacts. Each negative control must fail the task and move the stage by less
than 1 µm. Results and measured 50 Hz body poses are written for each trial.

To build a reusable scene and open an interactive desktop viewer:

```sh
python robotics/build_gripper_scene.py --output robotics/transfer_gripper.xml
python robotics/view_gripper.py --autoplay
```

The portable viewer shows the instrument's actual contact proxies and the Panda
visual meshes. Detailed instrument visuals are provided separately by the web
gallery. The robot benchmark is not a browser-live robot controller.
Viewer controls: A/D move X, S/W move Y, F/R move Z (2 mm per press); Q/E roll
by 5°; O/C open/close; Space toggles baseline playback; Backspace resets.
Keyboard moves are actuator commands with finite rate/force limits.

For policies, import `robotics.gripper_task.GripperTask`, call `reset(seed)`, then
`step(action)` at 50 Hz. Actions are `wrist_x`, `wrist_y`, `wrist_z` in metres,
`wrist_roll` in radians, and `aperture` as the per-finger target in metres
(0 to 0.04). `report()` evaluates progress, contact forces, penetration, screw
residual, passive settling and unwanted contacts. The initial pose is an open
gripper already above the knob; long-range approach planning is outside this task.

## Scope and provenance

Instrument inertias, friction and contact proxies are engineering estimates,
not measured calibration. Flexible hoses are visual-only in the instrument;
they require a separate swept visual-clearance audit. The small 15° turn avoids
the nearby breadboard; larger turns need regrasp planning. This is one contact
manipulation task, not general validation of every instrument or dexterous hand.

`assets/transfer/physics.xml` and `metadata.json` are the public transfer assets.
The composed model removes their instrument actuators while retaining their
masses, inertias, joints, friction, travel limits, interlocks and screw equalities.
Panda hand/finger geometry and inertials are from DeepMind MuJoCo Menagerie,
commit `eea4c7431b63da8278b0ff31638e0b0e941cec0e`, under Apache 2.0. The original
license and per-file SHA256 source manifest are included under
`robotics/assets/panda_gripper/`. The Cartesian adapter/servos and robot contact
friction are explicit benchmark estimates. `package_manifest.json` fingerprints
the reproducible inputs.
