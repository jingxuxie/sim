"""Compose the passive transfer instrument and a licensed Panda gripper.

The robot's four-axis Cartesian wrist is an explicit test fixture, not a robot
arm. The instrument retains its native masses, joints, contacts and equalities;
its bench actuators are removed from this composed scene.
"""
from copy import deepcopy
import json
import os
from pathlib import Path
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]
VENDOR = ROOT / 'robotics/assets/panda_gripper'
INSTRUMENT_XML = ROOT/'001_transfer_stage/transfer_station.xml'
INSTRUMENT_METADATA = ROOT/'001_transfer_stage/asset.json'
if not INSTRUMENT_XML.exists():
    INSTRUMENT_XML = ROOT/'assets/transfer/physics.xml'
    INSTRUMENT_METADATA = ROOT/'assets/transfer/metadata.json'


def build(destination, visuals=True):
    destination = Path(destination).resolve()
    top = ET.parse(INSTRUMENT_XML).getroot()
    top.set('model', 'transfer_panda_gripper_contact')
    compiler = top.find('compiler')
    meshroot = INSTRUMENT_XML.parent / compiler.attrib.pop('meshdir', '')
    for mesh in top.find('asset').findall('mesh'):
        mesh.set('file', os.path.relpath(meshroot / mesh.get('file'), destination.parent))
    compiler.set('inertiafromgeom', 'false')
    original_actuators = [x.attrib.copy() for x in top.find('actuator')]
    top.remove(top.find('actuator'))
    actuator = ET.SubElement(top, 'actuator')
    if not visuals:
        for body in top.iter('body'):
            for geom in list(body.findall('geom')):
                if geom.get('class') == 'visual':
                    body.remove(geom)
        for mesh in list(top.find('asset').findall('mesh')):
            top.find('asset').remove(mesh)
    panda = ET.parse(VENDOR / 'panda.xml').getroot()
    defaults = deepcopy(panda.find('default/default'))
    classes = {x.get('class'): 'panda_' + x.get('class') for x in defaults.iter('default')}
    for node in defaults.iter():
        if node.get('class') in classes:
            node.set('class', classes[node.get('class')])
    # Panda defaults retain their source inertial, armature, pad and joint data.
    collision = defaults.find(".//default[@class='panda_collision']/geom")
    collision.set('contype', '1')
    collision.set('conaffinity', '3')
    collision.set('condim', '4')
    collision.set('friction', '1 .002 .0001')
    collision.set('solref', '.003 1')
    collision.set('solimp', '.95 .995 .0001')
    top.find('default').append(defaults)
    assets = top.find('asset')
    mesh_names = {'hand_c', 'finger_0', 'finger_1', *(f'hand_{i}' for i in range(5))}
    for node in panda.find('asset'):
        if node.tag == 'material':
            new = deepcopy(node)
            new.set('name', 'panda_' + node.get('name'))
            new.set('class', 'panda_panda')
            assets.append(new)
        elif node.tag == 'mesh':
            name = node.get('name', Path(node.get('file')).stem)
            if name not in mesh_names:
                continue
            if not visuals and name not in ('hand_c', 'finger_0'):
                continue
            new = deepcopy(node)
            new.set('name', 'panda_' + name)
            new.set('file', os.path.relpath(VENDOR / 'assets' / node.get('file'), destination.parent))
            assets.append(new)
    hand = deepcopy(panda.find(".//body[@name='hand']"))
    hand.set('pos', '0 0 .1099')
    hand.set('quat', '0 1 0 0')
    hand.set('childclass', 'panda_panda')
    for node in hand.iter():
        for attribute in ('name', 'mesh', 'material'):
            if node.get(attribute):
                node.set(attribute, 'panda_' + node.get(attribute))
        if node.get('class'):
            node.set('class', classes[node.get('class')])
        if node.tag == 'body':
            node.set('gravcomp', '1')
    for body in hand.iter('body'):
        for i, geom in enumerate(body.findall('geom')):
            if not geom.get('name'):
                geom.set('name', body.get('name') + '_geom_' + str(i))
            if not visuals and geom.get('class') == 'panda_visual':
                body.remove(geom)
    # TCP pivot lies on the knob axis, 6 mm towards its outboard end. Pads
    # enter from above, with their centers 7 mm above the shaft centerline.
    wrist = ET.SubElement(top.find('worldbody'), 'body', name='robot_wrist',
                          pos='-.207 -.020 .035', gravcomp='1')
    ET.SubElement(wrist, 'inertial', mass='.05', pos='0 0 0', diaginertia='.00001 .00001 .00001')
    for name, axis in [('x', '1 0 0'), ('y', '0 1 0'), ('z', '0 0 1')]:
        ET.SubElement(wrist, 'joint', name='wrist_' + name, type='slide', axis=axis,
                      range='-.1 .1', damping='1')
        ET.SubElement(actuator, 'position', name='wrist_' + name + '_drive',
                      joint='wrist_' + name, kp='5000', kv='100',
                      ctrlrange='-.1 .1', forcerange='-60 60')
    ET.SubElement(wrist, 'joint', name='wrist_roll', type='hinge', axis='-1 0 0',
                  range='-1.2 1.2', damping='.01')
    ET.SubElement(actuator, 'position', name='wrist_roll_drive', joint='wrist_roll',
                  kp='3', kv='.3', ctrlrange='-1.2 1.2', forcerange='-1 1')
    wrist.append(hand)
    ET.SubElement(wrist, 'site', name='robot_tcp', size='.002', rgba='0 1 0 1')
    tendon = ET.SubElement(top, 'tendon')
    split = ET.SubElement(tendon, 'fixed', name='panda_split')
    for joint in ('panda_finger_joint1', 'panda_finger_joint2'):
        ET.SubElement(split, 'joint', joint=joint, coef='.5')
    ET.SubElement(top.find('equality'), 'joint', name='panda_finger_coupling',
                  joint1='panda_finger_joint1', joint2='panda_finger_joint2',
                  solimp='.95 .99 .001', solref='.005 1')
    ET.SubElement(actuator, 'general', name='panda_grip', tendon='panda_split',
                  dyntype='none', biastype='affine', gainprm='.01568627451 0 0',
                  biasprm='0 -100 -10', ctrlrange='0 255', forcerange='-100 100')
    world = top.find('worldbody')
    ET.SubElement(world, 'camera', name='robot_overview', pos='-.61 -.40 .39',
                  xyaxes='.62 -.78 0 .42 .33 .85', fovy='40')
    ET.SubElement(world, 'camera', name='robot_contact', pos='-.38 -.20 .16',
                  xyaxes='.65 -.76 0 .31 .26 .91', fovy='35')
    ET.indent(top)
    destination.parent.mkdir(parents=True, exist_ok=True)
    ET.ElementTree(top).write(destination, encoding='unicode')
    return dict(instrument='transfer', instrument_actuators_removed=original_actuators,
                robot='Franka Panda parallel gripper',
                wrist='Four-axis Cartesian end-effector fixture; no arm links or arm policy',
                visuals=visuals, scene=str(destination))


if __name__ == '__main__':
    import argparse
    p = argparse.ArgumentParser()
    p.add_argument('--output', type=Path, default=ROOT/'robotics/transfer_gripper.xml')
    p.add_argument('--collision-only', action='store_true')
    args = p.parse_args()
    result = build(args.output, not args.collision_only)
    print(json.dumps(result, indent=2))
