"""Native MuJoCo viewer for the explicitly labeled Cartesian gripper fixture."""
import argparse
from collections import deque
import math
import time
import mujoco.viewer
try:
    from .gripper_task import GripperTask
except ImportError:
    from gripper_task import GripperTask

parser = argparse.ArgumentParser()
parser.add_argument('--autoplay', action='store_true', help='Run the 12 s contact baseline once')
args = parser.parse_args()
task = GripperTask(visuals=True)
autoplay = args.autoplay
keys = deque()


def handle_key(key):
    global autoplay
    if key == 32:
        autoplay = not autoplay
        return
    if key == 259:  # GLFW Backspace; reset is the only teleport operation.
        task.reset()
        return
    increments = {'A': (0, -.002), 'D': (0, .002), 'S': (1, -.002), 'W': (1, .002),
                  'F': (2, -.002), 'R': (2, .002),
                  'Q': (3, -math.radians(5)), 'E': (3, math.radians(5))}
    names = ['wrist_x', 'wrist_y', 'wrist_z', 'wrist_roll', 'aperture']
    letter = chr(key).upper() if 0 <= key <= 0x10ffff else ''
    if letter in increments:
        index, delta = increments[letter]
        task.command({names[index]: task.commands[index]+delta})
        autoplay = False
    elif letter in ('O', 'C'):
        task.command({'aperture': .035 if letter == 'O' else 0.})
        autoplay = False


print('Cartesian wrist fixture: A/D X, S/W Y, F/R Z (2 mm), Q/E roll (5 deg), '
      'O/C open/close, Space baseline on/off, Backspace reset. No articulated arm.')
with mujoco.viewer.launch_passive(task.m, task.d, key_callback=keys.append) as viewer:
    viewer.cam.lookat[:] = [-.16, -.02, .12]
    viewer.cam.distance = .58
    viewer.cam.azimuth = 220
    viewer.cam.elevation = -22
    # Contact proxies are available under Rendering > Geom groups > 3.
    instrument_visuals = any(task.m.geom_group[i] == 2 and i not in task.robot_geoms
                             for i in range(task.m.ngeom))
    viewer.opt.geomgroup[3] = 0 if instrument_visuals else 1
    while viewer.is_running():
        started = time.monotonic()
        while keys:
            handle_key(keys.popleft())
        if autoplay and task.d.time < 12:
            task.step(task.baseline())
        else:
            task.step()
        viewer.sync()
        time.sleep(max(0., .02-(time.monotonic()-started)))
