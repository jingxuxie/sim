"""Contact-only Panda-gripper micrometer benchmark.

Robot actions command finite-force wrist and finger actuators. No instrument
actuator, applied wrench, kinematic attachment or runtime qpos write is used.
The wrist is a four-axis Cartesian fixture, not a simulated robot arm.
"""
from pathlib import Path
import argparse
import hashlib
import json
import math
import tempfile

import mujoco as mj
import numpy as np

try:
    from .build_gripper_scene import build, ROOT, INSTRUMENT_XML, INSTRUMENT_METADATA
except ImportError:
    from build_gripper_scene import build, ROOT, INSTRUMENT_XML, INSTRUMENT_METADATA


class GripperTask:
    TARGET_RAD = math.radians(-15)
    LEAD_M = .0005 / (2 * math.pi)
    KNOB = 'sample_x_knob__sample_x_grip'

    def __init__(self, scene=None, visuals=False, mode='contact', seed=0):
        self.asset = 'transfer'
        self.root = INSTRUMENT_XML.parent
        self.meta = json.loads(INSTRUMENT_METADATA.read_text())
        self.input_paths = [Path(__file__), ROOT/'robotics/build_gripper_scene.py',
                            INSTRUMENT_XML, INSTRUMENT_METADATA,
                            ROOT/'robotics/assets/panda_gripper/SOURCE.json']
        vendor = ROOT/'robotics/assets/panda_gripper'
        source = json.loads((vendor/'SOURCE.json').read_text())
        for name, record in source['files'].items():
            path = vendor/name
            if hashlib.sha256(path.read_bytes()).hexdigest() != record['sha256']:
                raise ValueError('Vendor source fingerprint changed: ' + name)
            self.input_paths.append(path)
        self.inputs_before = {p.relative_to(ROOT).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest()
                              for p in self.input_paths}
        self.fixtures = False
        self.controller = None
        self.mode = mode
        self._tmp = None
        if scene is None:
            self._tmp = tempfile.TemporaryDirectory(prefix='gripper-contact-')
            scene = Path(self._tmp.name)/'scene.xml'
            build(scene, visuals)
        self.scene = Path(scene)
        self.scene_hash = hashlib.sha256(self.scene.read_bytes()).hexdigest()
        self.m = mj.MjModel.from_xml_path(str(scene))
        self.m.opt.enableflags |= mj.mjtEnableBit.mjENBL_MULTICCD
        expected_actuators = ['wrist_x_drive', 'wrist_y_drive', 'wrist_z_drive', 'wrist_roll_drive', 'panda_grip']
        actual_actuators = [self.m.actuator(i).name for i in range(self.m.nu)]
        if actual_actuators != expected_actuators:
            raise ValueError('Scene must contain exactly the four wrist drives and Panda grip actuator')
        self.d = mj.MjData(self.m)
        self.joints = {self.m.joint(i).name: i for i in range(self.m.njnt)}
        self.robot_dofs = {self.m.joint(n).dofadr[0] for n in
                          ['wrist_x', 'wrist_y', 'wrist_z', 'wrist_roll',
                           'panda_finger_joint1', 'panda_finger_joint2']}
        self.instrument_dofs = np.array([i for i in range(self.m.nv) if i not in self.robot_dofs])
        self.robot_bodies = {i for i in range(self.m.nbody)
                            if self.m.body(i).name.startswith(('panda_', 'robot_'))}
        self.instrument_bodies = np.array([i for i in range(1, self.m.nbody) if i not in self.robot_bodies])
        for i in range(self.m.neq):
            if self.m.eq_type[i] in (mj.mjtEq.mjEQ_WELD, mj.mjtEq.mjEQ_CONNECT):
                attached = int(self.m.eq_obj1id[i]) in self.robot_bodies
                other = int(self.m.eq_obj2id[i]) in self.robot_bodies
                if attached != other:
                    raise ValueError('Robot-to-instrument attachments are forbidden in this contact task')
        self.robot_geoms = {i for i in range(self.m.ngeom) if self.m.geom_bodyid[i] in self.robot_bodies}
        self.pads = {'left': set(), 'right': set()}
        for i in self.robot_geoms:
            for side in self.pads:
                if self.m.geom(i).name.startswith('panda_' + side + '_finger'):
                    self.pads[side].add(i)
        self.knob_id = self.m.geom(self.KNOB).id
        # The same controlled knob has separate thimble, collar and handwheel
        # proxies. All are legitimate contact targets; neighboring stage parts
        # remain unintended contacts. Visual-only surfaces are excluded.
        knob_body = int(self.m.geom_bodyid[self.knob_id])
        self.knob_geoms = {i for i in range(self.m.ngeom)
                           if int(self.m.geom_bodyid[i]) == knob_body
                           and (self.m.geom_contype[i] or self.m.geom_conaffinity[i])}
        self.nominal_wrist = self.m.body_pos[self.m.body('robot_wrist').id].copy()
        self.nominal_masks = self.m.geom_contype.copy(), self.m.geom_conaffinity.copy()
        self.reset(seed)

    def reset(self, seed=0):
        self.seed = int(seed)
        self.rng = np.random.default_rng(seed)
        mj.mj_resetData(self.m, self.d)
        self._lock_prev = {}
        self.guard_events = []
        self.m.geom_contype[:] = self.nominal_masks[0]
        self.m.geom_conaffinity[:] = self.nominal_masks[1]
        if self.mode == 'contacts_disabled':
            for i in self.robot_geoms:
                self.m.geom_contype[i] = 0
                self.m.geom_conaffinity[i] = 0
        offset = np.array([0., self.rng.uniform(-.0002, .0002), self.rng.uniform(-.0002, .0002)])
        if self.mode == 'missed_grasp':
            offset[0] -= .06
        self.m.body_pos[self.m.body('robot_wrist').id] = self.nominal_wrist + offset
        self.initial_wrist_offset = offset.tolist()
        for name, value in self.meta.get('initial_joint_positions', {}).items():
            self.d.qpos[self.m.joint(name).qposadr[0]] = float(value)
        if 'light_path_travel' in self.joints:
            self.d.qpos[self.m.joint('light_path_travel').qposadr[0]] = .012
        for n in ('panda_finger_joint1', 'panda_finger_joint2'):
            self.d.qpos[self.m.joint(n).qposadr[0]] = .035
        self.commands = np.array([0., 0., 0., 0., .035])
        self.d.ctrl[:4] = 0
        self.d.ctrl[4] = .035/.04*255
        mj.mj_forward(self.m, self.d)
        self.start_x = self.q('sample_x_travel')
        self.peak_force = 0.
        self.peak_actuator_forces = np.zeros(self.m.nu)
        self.peak_penetration = 0.
        self.unintended = []
        self.unintended_count = 0
        self.bilateral_steps = 0
        self.turn_bilateral_steps = 0
        self.robot_instrument_steps = 0
        self.peak_instrument_actuator_force = 0.
        self.peak_instrument_applied_force = 0.
        self.peak_instrument_applied_wrench = 0.
        self.max_gear_residual = 0.
        self.trajectory = []
        self.contact_trace = []
        self.events = []
        self.released_at = None
        self.last_contacts = {'left': 0., 'right': 0., 'unintended_N': 0.}
        self.history = []
        return self.observe()

    def command(self, action):
        allowed = {'wrist_x', 'wrist_y', 'wrist_z', 'wrist_roll', 'aperture'}
        if set(action)-allowed:
            raise ValueError('Only robot commands are accepted: ' + ', '.join(sorted(allowed)))
        for i, name in enumerate(['wrist_x', 'wrist_y', 'wrist_z', 'wrist_roll', 'aperture']):
            if name not in action:
                continue
            value = float(action[name])
            if not math.isfinite(value):
                raise ValueError('Robot command must be finite')
            limits = (0, .04) if name == 'aperture' else (-1.2, 1.2) if name == 'wrist_roll' else (-.1, .1)
            self.commands[i] = np.clip(value, *limits)
        return self.commands.tolist()

    def before_step(self):
        # Retain the native transfer's physically switched coarse/fine locks.
        if self.meta.get('rotation_mechanism'):
            locked = self.q('rotation_lock_angle') >= self.meta['rotation_mechanism']['lock_threshold_rad']
            self._lock('rotation_coarse_lock', locked)
            self._lock('rotation_fine_lock', not locked)
        dt = self.m.opt.timestep
        rates = [.025, .025, .025, .3, .015]
        for i in range(4):
            self.d.ctrl[i] += np.clip(self.commands[i]-self.d.ctrl[i], -rates[i]*dt, rates[i]*dt)
        aperture = self.d.ctrl[4]/255*.04
        aperture += np.clip(self.commands[4]-aperture, -rates[4]*dt, rates[4]*dt)
        self.d.ctrl[4] = aperture/.04*255

    def q(self, name):
        return float(self.d.qpos[self.m.joint(name).qposadr[0]])

    def _lock(self, name, active):
        index = self.m.equality(name).id
        if active and not self._lock_prev.get(name, False):
            joint = int(self.m.eq_obj1id[index])
            self.m.eq_data[index, 0] = self.d.qpos[self.m.jnt_qposadr[joint]]
        self.d.eq_active[index] = active
        self._lock_prev[name] = active

    def baseline(self):
        t = self.d.time
        roll = self.TARGET_RAD if self.mode != 'no_turn' else 0.
        if t < .5:
            return {'aperture': .035, 'wrist_roll': 0., 'wrist_z': 0.}
        if t < 3.4:
            return {'aperture': 0., 'wrist_roll': 0., 'wrist_z': 0.}
        if t < 6.5:
            return {'aperture': 0., 'wrist_roll': roll, 'wrist_z': 0.}
        if t < 8.5:
            # Release at the grasp pose first. Opening to 16 mm per finger clears
            # the 22 mm knob while preserving breadboard clearance at 15 degrees.
            return {'aperture': .016, 'wrist_roll': roll, 'wrist_z': 0.}
        return {'aperture': .035, 'wrist_roll': roll, 'wrist_z': .035}

    def step(self, action=None, seconds=.02):
        if action:
            self.command(action)
        for _ in range(max(1, round(seconds/self.m.opt.timestep))):
            self.before_step()
            mj.mj_step(self.m, self.d)
            self.audit_step()
        return self.observe()

    def audit_step(self):
        forces = {'left': 0., 'right': 0., 'unintended_N': 0.}
        force = np.zeros(6)
        for i, contact in enumerate(self.d.contact):
            a, b = int(contact.geom1), int(contact.geom2)
            if (a in self.robot_geoms) == (b in self.robot_geoms):
                continue
            mj.mj_contactForce(self.m, self.d, i, force)
            normal = max(0., float(force[0]))
            self.peak_force = max(self.peak_force, normal)
            self.peak_penetration = max(self.peak_penetration, -float(contact.dist))
            robot, instrument = (a, b) if a in self.robot_geoms else (b, a)
            if instrument in self.knob_geoms:
                self.robot_instrument_steps += 1
                for side, ids in self.pads.items():
                    if robot in ids:
                        forces[side] += normal
            elif normal > .01:
                self.unintended_count += 1
                forces['unintended_N'] += normal
                if len(self.unintended) < 30:
                    self.unintended.append(dict(time_s=float(self.d.time), robot=self.m.geom(robot).name,
                                               instrument=self.m.geom(instrument).name, normal_N=normal,
                                               penetration_m=max(0., -float(contact.dist))))
        self.last_contacts = forces
        if min(forces['left'], forces['right']) > .05:
            self.bilateral_steps += 1
            if 3.4 <= self.d.time <= 6.5:
                self.turn_bilateral_steps += 1
            if not any(e['event'] == 'bilateral_grasp' for e in self.events):
                self.events.append(dict(event='bilateral_grasp', time_s=float(self.d.time)))
        if self.d.time > 6.5 and self.released_at is None and max(forces['left'], forces['right']) < .01:
            self.released_at = float(self.d.time)
            self.events.append(dict(event='released', time_s=self.released_at))
        self.peak_instrument_actuator_force = max(self.peak_instrument_actuator_force,
            float(np.max(np.abs(self.d.qfrc_actuator[self.instrument_dofs]))))
        self.peak_instrument_applied_force = max(self.peak_instrument_applied_force,
            float(np.max(np.abs(self.d.qfrc_applied[self.instrument_dofs]))))
        self.peak_instrument_applied_wrench = max(self.peak_instrument_applied_wrench,
            float(np.max(np.abs(self.d.xfrc_applied[self.instrument_bodies]))))
        self.peak_actuator_forces = np.maximum(self.peak_actuator_forces, np.abs(self.d.actuator_force))
        residual = abs(self.q('sample_x_travel') - self.LEAD_M*self.q('sample_x_angle'))
        self.max_gear_residual = max(self.max_gear_residual, residual)
        self.history.append((float(self.d.time), self.q('sample_x_travel')))

    def observe(self):
        return dict(time_s=float(self.d.time), stage_x_m=self.q('sample_x_travel'),
                    knob_angle_rad=self.q('sample_x_angle'), wrist_roll_rad=self.q('wrist_roll'),
                    wrist_xyz_m=[self.q('wrist_'+a) for a in 'xyz'],
                    finger_positions_m=[self.q('panda_finger_joint'+str(i)) for i in (1, 2)],
                    contact_N=dict(self.last_contacts), warnings=self.d.warning.number.tolist())

    def run(self, duration=12., record=True):
        while self.d.time < duration-1e-7:
            self.step(self.baseline())
            if record:
                # mj_step integrates qpos after evaluating geometry. Refresh
                # body transforms so recorded poses and qpos share the timestamp.
                mj.mj_kinematics(self.m, self.d)
                observation = self.observe()
                frame = dict(t=float(self.d.time), qpos=self.d.qpos.tolist(), observation=observation,
                             poses={self.m.body(i).name: dict(p=self.d.xpos[i].tolist(), q=self.d.xquat[i].tolist())
                                    for i in range(1, self.m.nbody)})
                self.trajectory.append(frame)
        return self.report()

    def report(self):
        goal = self.LEAD_M*self.TARGET_RAD
        final_error = abs(self.q('sample_x_travel')-self.start_x-goal)
        tail = [q for t, q in self.history if t >= self.d.time-.5]
        settling_range = max(tail)-min(tail) if tail else float('inf')
        final_speed = float(self.d.qvel[self.m.joint('sample_x_travel').dofadr[0]])
        inputs_after = {p.relative_to(ROOT).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest()
                        for p in self.input_paths}
        scene_unchanged = hashlib.sha256(self.scene.read_bytes()).hexdigest() == self.scene_hash
        success = (final_error < 5e-6 and self.turn_bilateral_steps >= 300
                   and not self.unintended and self.released_at is not None
                   and self.q('wrist_z') > .025 and self.peak_force < 10
                   and self.peak_penetration < .0003 and self.max_gear_residual < 5e-6
                   and self.peak_instrument_actuator_force == 0
                   and self.peak_instrument_applied_force == 0 and self.peak_instrument_applied_wrench == 0
                   and not self.d.warning.number.any()
                   and settling_range < 2e-6 and abs(final_speed) < 1e-6
                   and inputs_after == self.inputs_before and scene_unchanged)
        return dict(task='transfer.gripper_turn_sample_x', mode=self.mode, seed=self.seed,
                    success=bool(success), duration_s=float(self.d.time),
                    target_knob_angle_rad=self.TARGET_RAD, target_stage_displacement_m=goal,
                    measured_stage_displacement_m=self.q('sample_x_travel')-self.start_x,
                    final_stage_error_m=final_error, measured_knob_angle_rad=self.q('sample_x_angle'),
                    bilateral_contact_steps=self.bilateral_steps, turn_bilateral_contact_steps=self.turn_bilateral_steps,
                    peak_normal_force_N=self.peak_force, peak_penetration_m=self.peak_penetration,
                    robot_peak_actuator_forces={self.m.actuator(i).name:float(x) for i,x in enumerate(self.peak_actuator_forces)},
                    max_screw_residual_m=self.max_gear_residual,
                    last_half_second_stage_range_m=settling_range, final_stage_speed_m_s=final_speed,
                    peak_instrument_actuator_force=self.peak_instrument_actuator_force,
                    peak_instrument_applied_generalized_force=self.peak_instrument_applied_force,
                    peak_instrument_applied_body_wrench=self.peak_instrument_applied_wrench,
                    instrument_actuator_count=0, robot_actuator_count=self.m.nu,
                    unintended_contact_count=self.unintended_count,
                    unintended_contacts=self.unintended, released_at_s=self.released_at,
                    final=self.observe(), events=self.events,
                    initial_wrist_offset_m=self.initial_wrist_offset,
                    robot='Franka Panda parallel gripper',
                    wrist='Four-axis Cartesian fixture; no articulated arm',
                    target_contact_shapes=[self.m.geom(i).name for i in sorted(self.knob_geoms)],
                    nominal_wrist_position_m=self.nominal_wrist.tolist(),
                    mujoco_version=mj.__version__, inputs_before=self.inputs_before,
                    inputs_unchanged=inputs_after == self.inputs_before,
                    scene_sha256=self.scene_hash, scene_unchanged=scene_unchanged)

    def trajectory_payload(self, report):
        return dict(schema_version=1, task=report['task'], asset='transfer_gripper',
                    instrument='transfer', robot=report['robot'], wrist=report['wrist'],
                    passed=report['success'], mode=report['mode'], seed=report['seed'],
                    mujoco_version=report['mujoco_version'], source_hashes=report['inputs_before'],
                    joint_layout={self.m.joint(i).name: dict(qpos_address=int(self.m.jnt_qposadr[i]),
                                  type=int(self.m.jnt_type[i])) for i in range(self.m.njnt)},
                    frames=self.trajectory)


if __name__ == '__main__':
    p = argparse.ArgumentParser()
    p.add_argument('--scene', type=Path)
    p.add_argument('--mode', choices=['contact', 'contacts_disabled', 'missed_grasp', 'no_turn'], default='contact')
    p.add_argument('--seed', type=int, default=0)
    p.add_argument('--duration', type=float, default=12)
    p.add_argument('--output', type=Path, default=ROOT/'validation/robotics/development')
    p.add_argument('--visuals', action='store_true')
    args = p.parse_args()
    task = GripperTask(args.scene, args.visuals, args.mode, args.seed)
    report = task.run(args.duration)
    args.output.mkdir(parents=True, exist_ok=True)
    (args.output/'report.json').write_text(json.dumps(report, indent=2)+'\n')
    (args.output/'trajectory.json').write_text(json.dumps(task.trajectory_payload(report), separators=(',', ':'))+'\n')
    print(json.dumps(report, indent=2))
