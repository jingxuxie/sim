"""Run contact-driven micrometer trials and paired causal negative controls."""
from pathlib import Path
import argparse
import json

try:
    from .gripper_task import GripperTask, ROOT
except ImportError:
    from gripper_task import GripperTask, ROOT


def save_trial(task, report, destination):
    destination.mkdir(parents=True, exist_ok=True)
    (destination/'report.json').write_text(json.dumps(report, indent=2)+'\n')
    payload = task.trajectory_payload(report)
    (destination/'trajectory.json').write_text(json.dumps(payload, separators=(',', ':'))+'\n')


def validate(destination, seeds=(0, 11, 37)):
    destination = Path(destination)
    trials = []
    for seed in seeds:
        for mode in ('contact', 'contacts_disabled', 'missed_grasp', 'no_turn'):
            task = GripperTask(mode=mode, seed=seed)
            report = task.run()
            folder = destination/mode/('seed_'+str(seed))
            save_trial(task, report, folder)
            if mode == 'contact':
                check = report['success']
            else:
                # The same command must fail without a grasp/turn, while the
                # passive stage remains at its starting position within 1 um.
                check = (not report['success']
                         and abs(report['measured_stage_displacement_m']) < 1e-6
                         and report['peak_instrument_actuator_force'] == 0
                         and report['peak_instrument_applied_generalized_force'] == 0
                         and report['peak_instrument_applied_body_wrench'] == 0
                         and not any(report['final']['warnings'])
                         and report['inputs_unchanged'])
                if mode in ('contacts_disabled', 'missed_grasp'):
                    check = check and report['bilateral_contact_steps'] == 0
            trials.append(dict(mode=mode, seed=seed, check_passed=bool(check),
                               task_success=report['success'],
                               stage_displacement_um=report['measured_stage_displacement_m']*1e6,
                               goal_error_um=report['final_stage_error_m']*1e6,
                               peak_normal_force_N=report['peak_normal_force_N'],
                               max_penetration_um=report['peak_penetration_m']*1e6,
                               unintended_contact_count=report['unintended_contact_count'],
                               report=folder.relative_to(destination).as_posix()+'/report.json'))
            print(json.dumps(trials[-1]), flush=True)
            if task._tmp:
                task._tmp.cleanup()
    report = dict(schema_version=1, passed=all(t['check_passed'] for t in trials),
                  task='transfer.gripper_turn_sample_x', seeds=list(seeds), trials=trials,
                  negative_control_tolerance_um=1,
                  scope='Native MuJoCo contact task; Cartesian wrist fixture, no articulated arm',
                  limitations=['Estimated instrument inertias and friction; not measured calibration',
                               'Flexible hoses are visual only; separate swept visual clearance audit required',
                               'Robot benchmark is native Python, not a browser robot controller'])
    (destination/'summary.json').write_text(json.dumps(report, indent=2)+'\n')
    return report


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--out', type=Path, default=ROOT/'validation/robotics')
    parser.add_argument('--seeds', type=int, nargs='+', default=[0, 11, 37])
    args = parser.parse_args()
    result = validate(args.out, args.seeds)
    print(json.dumps(result, indent=2))
    raise SystemExit(0 if result['passed'] else 1)
